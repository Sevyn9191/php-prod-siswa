
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Registration Edit</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Registration</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <?php foreach($lumia as $row) { ?>
      <form action="" method="post">
        <?php form_open('daftar'); ?>
        <div class="row">
          <div class="col-md-12">

            <div class="card card-success">
              <div class="card-header">
                <h3 class="card-title">Enter applicant data</h3>
              </div>
              <div class="card-body">
                <!-- Date dd/mm/yyyy -->
                <div class="row">
                    <div class="col-md-6">
                        <input type="hidden" name="id" value="<?php echo $row['No_Daftar']; ?>">
                        <div class="form-group">
                            <label>Cost Statement</label>

                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-square"></i></span>
                                </div>
                                <input type="text" class="form-control" name="nama" id="nama" value="<?php echo $row['Nm_CaSis']; ?>">
                            </div>
                            <!-- /.input group -->
                            <?= form_error('nama','<small class="text-danger pl-3">','</small>'); ?>
                        </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Register date</label>

                          <div class="input-group">
                            <div class="input-group-prepend">
                              <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                            </div>
                            <input type="text" class="form-control" name="tgl_daftar" data-inputmask-alias="datetime" value="<?php echo $row['Tgl_Lahir']; ?>" data-inputmask-inputformat="yyyy/mm/dd" data-mask readonly>
                          </div>
                      <!-- /.input group -->
                      <?= form_error('tgl_daftar','<small class="text-danger pl-3">','</small>'); ?>
                      </div>
                    <!-- /.form group -->
                    </div>

                  </div>
                  <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>School Origin</label>

                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-book"></i></span>
                                </div>
                                <input type="text" class="form-control" name="asal_sekolah" id="asal_sekolah" value="<?php echo $row['As_Sek']; ?>">
                            </div>
                            <!-- /.input group -->
                            <?= form_error('asal_sekolah','<small class="text-danger pl-3">','</small>'); ?>
                        </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Birthpace</label>

                          <div class="input-group">
                            <div class="input-group-prepend">
                              <span class="input-group-text"><i class="fas fa-map-marker-alt mr-1"></i></span>
                            </div>
                            <input type="text" class="form-control" name="tmpt_lahir" id="tmpt_lahir" value="<?php echo $row['Tmpt_Lahir']; ?>">
                          </div>
                      <!-- /.input group -->
                      <?= form_error('tmpt_lahir','<small class="text-danger pl-3">','</small>'); ?>
                      </div>
                    <!-- /.form group -->
                    </div>

                  </div>

                  <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Date of birth</label>

                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="far fa-clock"></i></span>
                                </div>
                                <input type="text" class="form-control" name="born" data-inputmask-alias="datetime" value="<?php echo $row['Tgl_Lahir']; ?>" data-inputmask-inputformat="yyyy/mm/dd" data-mask>
                            </div>
                            <!-- /.input group -->
                            <?= form_error('born','<small class="text-danger pl-3">','</small>'); ?>
                          
                        </div>
                    </div>

                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Gender</label>

                          <div class="input-group">
                            <div class="input-group-prepend">
                              <span class="input-group-text"><i class="fas fa-sync-alt"></i></span>
                            </div>
                            <select name="gender" id="" class="form-control">
                              <option value="Pria">Pria</option>
                              <option value="Perempuan">Perempuan</option>
                            </select>
                            <!-- <input type="text" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy/mm/dd" data-mask> -->
                          </div>
                      <!-- /.input group -->
                      
                      </div>
                    <!-- /.form group -->
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Religion</label>

                          <div class="input-group">
                            <div class="input-group-prepend">
                              <span class="input-group-text"><i class="fas fa-laptop"></i></span>
                            </div>
                            <select name="religion" id="" class="form-control">
                              <option value="Mayoritas">Mayoritas</option>
                              <option value="Minoritas">Minoritas</option>
                            </select>
                            <!-- <input type="text" name="religion" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy/mm/dd" data-mask> -->
                          </div>
                      <!-- /.input group -->
                      </div>
                    <!-- /.form group -->
                    </div>

                  </div>
                  
                  
                  <input type="submit" value="Submit" class="btn btn-success" id="oke-jo"> 
            </div>
              <!-- /.card-body -->
          </div>
            <!-- /.card -->

            


          <!-- /.col (left) -->
          
        </div>
        <!-- /.row -->
        
      </form>
        <?php } ?>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  